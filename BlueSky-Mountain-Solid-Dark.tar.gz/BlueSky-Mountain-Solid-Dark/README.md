# BlueSky GTK Themes
Gtk2, Gtk3, Gnome shell, Cinnamon, Metacity, Xfwm4 themes base on [Arch-themes](https://github.com/horst3180/arc-theme) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
Theme can be download [here](https://www.pling.com/p/1271140/)</br></br>
SCREENSHOTS:</br>
![blueskyscreenshot](https://i.ibb.co/TWZsD9F/bluesky-light-screenshot.png "bluesky screenshot")</br>
![blueskyscreenshot](https://i.ibb.co/hLyPstJ/bluesky-dark-screenshot.png "bluesky screenshot")</br>
